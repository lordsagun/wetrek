<!DOCTYPE html>
<html>

<?php include 'includes/header.php'; ?>


<body>


	<section>
		<div class="banner">
			<img src="images/listing-banner.jpg" alt="banner" style="width: 100%;">
		</div>
		<div class="container">
			<div class="banner-cont">
				<h1>Nepal</h1>
				<span>Some tagline</span>
				<div class="detail-content">
				<p>Nepal is one of the most beautiful as well as amazing land within Asia and home to the world’s highest mountain “Mount Everest”. It is one of the richest countries in the world in terms of bio-diversity due to its unique geographical position and latitude variation. This is one of the most famous destinations in the world that offer an ever-growing range of outdoor activities.</p>
				<p>Nepal is one of the most beautiful as well as amazing land within Asia and home to the world’s highest mountain “Mount Everest”. It is one of the richest countries in the world in terms of bio-diversity due to its unique geographical position and latitude variation. This is one of the most famous destinations in the world that offer an ever-growing range of outdoor activities.Nepal is one of the most beautiful as well as amazing land within Asia and home to the world’s highest mountain “Mount Everest”. It is one of the richest countries in the world in terms of bio-diversity due to its unique geographical position and latitude variation. This is one of the most famous destinations in the world that offer an ever-growing range of outdoor activities.famous destinations in the world that offer an ever-growing range of outdoor activities.Nepal is one of the most beautiful as well as amazing land within Asia and home to the world’s highest mountain “Mount Everest”. It is one of the richest countries in the world in terms of bio-diversity due to its unique geographical position and latitude variation. This is one of the most famous destinations in the world that offer an ever-growing range of outdoor activities.famous destinations in the world that offer an ever-growing range of outdoor activities.Nepal is one of the most beautiful as well as amazing land within Asia and home to the world’s highest mountain “Mount Everest”. It is one of the richest countries in the world in terms of bio-diversity due to its unique geographical position and latitude variation. This is one of the most famous destinations in the world that offer an ever-growing range of outdoor activities.</p>
				</div>
			</div>
		</div>
	</section>

	<!-- <section>
		<div class="container listing-wrapper">
			<ul class="nav nav-pills">
			    <li class="active"><a data-toggle="pill" href="#nepal">Trekking</a></li>
			    <li><a data-toggle="pill" href="#tibet">Tours</a></li>
			    <li><a data-toggle="pill" href="#bhutan">Expedition</a></li>
			</ul>
			<div class="tab-content clearfix">
				<div id="nepal" class="tab-pane list-row in active clearfix">
					<div class="list-column">
						<div>
							<a href="#" class="image-box"><img src="images/list1.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination1</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list2.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list7.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
					</div>

					<div class="list-column">

						<div>
							<a href="#" class="image-box"><img src="images/list4.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination1</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list6.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list2.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
					</div>

					<div class="list-column">
						<div>
							<a href="#" class="image-box"><img src="images/list1.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination1</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list6.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list4.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
					</div>

					<div class="list-column">
						<div>
							<a href="#" class="image-box"><img src="images/list3.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination1</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list2.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list7.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
					</div>
				</div>

				<div id="tibet" class="tab-pane list-row">
					<div class="list-column">
						<div>
							<a href="#" class="image-box"><img src="images/list1.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination1</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list3.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list7.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
					</div>

					<div class="list-column">
						<div>
							<a href="#" class="image-box"><img src="images/list6.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination1</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list6.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous asdf ad fad fda fads fdf destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list4.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
					</div>

					<div class="list-column">
						<div>
							<a href="#" class="image-box"><img src="images/list4.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination1</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list6.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list7.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
					</div>

					<div class="list-column">
						<div>
							<a href="#" class="image-box"><img src="images/list1.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination1</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list3.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list1.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
					</div>
				</div>

				<div id="bhutan" class="tab-pane list-row">
					<div class="list-column">
						<div>
							<a href="#" class="image-box"><img src="images/list3.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination1</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list1.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list4.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
					</div>

					<div class="list-column">
						<div>
							<a href="#" class="image-box"><img src="images/list1.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination1</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list4.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list7.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
					</div>

					<div class="list-column">
						<div>
							<a href="#" class="image-box"><img src="images/list4.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination1</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list6.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list6.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
					</div>

					<div class="list-column">
						<div>
							<a href="#" class="image-box"><img src="images/list1.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination1</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list6.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
						<div>
							<a href="#" class="image-box"><img src="images/list2.jpg" alt="list"></a>
							<div class="list-detail">
								<h3>Destination2</h3>
								<p>ange of outdoor activities.famous destinations in the world that offer an ever-growing range </p>
								<a href="#">Read more</a>
							</div>
						</div>
					</div>
				</div>

			</div>
			

			<div class="page">
				<span><a href="#" class="active">1</a></span>
				<span><a href="#">2</a></span>
				<span><a href="#">3</a></span>
			</div>
		</div>
	</section> -->

	<!-- <section>
		<div class="container extra-details">
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<h3>Activities in Nepal</h3>
				<ul class="act-list">
					<li><a href="#"><i class="glyphicon glyphicon-menu-right"></i>Rafting</a></li>
					<li><a href="#"><i class="glyphicon glyphicon-menu-right"></i>Hiking</a></li>
					<li><a href="#"><i class="glyphicon glyphicon-menu-right"></i>Trekking</a></li>
					<li><a href="#"><i class="glyphicon glyphicon-menu-right"></i>Mountain Biking</a></li>
					<li><a href="#"><i class="glyphicon glyphicon-menu-right"></i>Wildlife safari</a></li>
				</ul>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<h3>General Info</h3>
				<ul class="act-list">
					<li><a href="#"><i class="glyphicon glyphicon-menu-right"></i>Festivals</a></li>
					<li><a href="#"><i class="glyphicon glyphicon-menu-right"></i>Nepal at Glance</a></li>
					<li><a href="#"><i class="glyphicon glyphicon-menu-right"></i>Accomodatin</a></li>
					<li><a href="#"><i class="glyphicon glyphicon-menu-right"></i>Safety and Skills</a></li>
					<li><a href="#"><i class="glyphicon glyphicon-menu-right"></i>Wildlife safari</a></li>
				</ul>
			</div>
			<div class="col-lg4 col-md-4 col-sm-4 col-xs-12">
				<h3>Enquiry Form</h3>
				<form>
					<input type="text" placeholder="Name">
				</form>
			</div>
		</div>
	</section>
 -->





<?php include 'includes/footer.php'; ?>

</body>

</html>