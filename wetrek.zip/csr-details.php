<!DOCTYPE html>
<html>

<?php include 'includes/header.php'; ?>


<body>
	
	<!-- blog page start -->

	<div class="csr-head">
		<div class="blog-banner">
			<div class="banner-content">
				<div class="container no-padding">
					<h1>CSR Article Head</h1>
				</div>
			</div>
		</div>
	</div>

	<div class="csr-content-wr">
		<div class="container">
			<div class="row">
				<div class="csr-banner-wr"><img src="images/banner.jpg" alt="csr"></div>
				<h3>Article head</h3>
				<h4>Article sub-head</h4>
				<p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod quis nostrud exercitation ullamco udied in the National Technical University of Athehe National Technical University of Athens, Greece (NTUA), with a Master  I am an Archit laboris nisi ut aliquip ex ea commodo Duis aute irure dolor in reprehenderit in voluptate velit essecillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non sunt in culpa qui officia deserunt mollit anim id est laborum. am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master  I am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master I am an Architect Engineer, studied in the National Technical University of Athehe National Technical University of Athens, Greece (NTUA), with a Masters, Greece (NTUA),  eiusmod quis nostrud exercitation ullamco udied in the National Technical University of Athehe National Technical University of Athens, Greece (NTUA), with a Master  I am an Archit laboris nisi ut aliquip ex ea commodo Duis aute irure dolor in University of Athehe National  velit essec with a Master I am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master .</p>
				<p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod quis nostrud exercitation ullamco udied in the National Technical University of Athehe National Technical University of Athens, Greece (NTUA), with a Master  I am an Archit laboris nisi ut aliquip ex ea commodo Duis aute irure dolor in reprehenderit in voluptate velit essecillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non sunt in culpa qui officia d</p>
				<div class="qa-wr">
					<strong>Social and Cultural Impact</strong>
					<p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod quis nostrud exercitation ullamco udied in the National Technical University of Athehe National Technical University of Athens, Greece (NTUA), with a Master  I am an Archit laboris nisi ut aliquip ex ea commodo Duis aute irure dolor in reprehenderit in voluptate velit essecillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non sunt in culpa qui officia d</p>
					<strong>Social and Cultural Impact</strong>
					<p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod quis nostrud exercitation ullamco udied in the National Technical University of Athehe National Technical University of Athens, Greece (NTUA), with a Master  I am an Archit laboris nisi ut aliquip ex ea commodo Duis aute irure dolor in reprehenderit in voluptate velit essecillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non sunt in culpa qui officia d</p>
					<strong>Social and Cultural Impact</strong>
					<p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod quis nostrud exercitation ullamco udied in the National Technical University of Athehe National Technical University of Athens, Greece (NTUA), with a Master  I am an Archit laboris nisi ut aliquip ex ea commodo Duis aute irure dolor in reprehenderit in voluptate velit essecillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non sunt in culpa qui officia d</p>
				</div>
				<div class="gallery-contain">
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4">
							<a href="#" class="gallery-wr"><img src="images/list1.jpg" alt="gallery"></a>
						</div>
						<div class="col-lg-4 col-md-4 col-sm-4">
							<a href="#" class="gallery-wr"><img src="images/list1.jpg" alt="gallery"></a>
						</div>
						<div class="col-lg-4 col-md-4 col-sm-4">
							<a href="#" class="gallery-wr"><img src="images/list1.jpg" alt="gallery"></a>
						</div>
					</div>
				</div>
				<div class="info-list-wr">
					<strong>Social and Cultural Impact</strong>
					<p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod quis nostrud exercitation ullamco udied in the National Technical University of Athehe National Technical University of Athens, Greece (NTUA), with a Master  I am an Archit laboris nisi ut aliquip ex ea commodo Duis aute irure dolor in reprehenderit in voluptate velit essecillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non sunt in culpa qui officia d</p>
					<ul class="csr-demo-list">
						<li><i class="fa fa-circle" aria-hidden="true"></i>Donations and gift giving</li>
						<li><i class="fa fa-circle" aria-hidden="true"></i>Donations and gift giving</li>
						<li><i class="fa fa-circle" aria-hidden="true"></i>aliquip ex ea commodo Duis aute irure dolo</li>
					</ul>
					<strong>Social Impact</strong>
					<ul class="csr-demo-list">
						<li><i class="fa fa-circle" aria-hidden="true"></i>Donations and gift giving</li>
						<li><i class="fa fa-circle" aria-hidden="true"></i>Donations and gift giving</li>
						<li><i class="fa fa-circle" aria-hidden="true"></i>aliquip ex ea commodo Duis aute irure dolo</li>
					</ul>
					<p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod quis nostrud exercitation ullamco udied in the National Technical University of Athehe National Technical University of Athens, Greece (NTUA), with a Master  I am an Archit laboris nisi ut aliquip ex ea commodo Duis aute irure dolor in reprehenderit in voluptate velit essecillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non sunt in culpa qui officia d</p>
					<strong>Social and Cultural Impact</strong>
					<ul class="csr-demo-list">
						<li><i class="fa fa-circle" aria-hidden="true"></i>Donations and gift giving</li>
						<li><i class="fa fa-circle" aria-hidden="true"></i>Donations and gift giving</li>
						<li><i class="fa fa-circle" aria-hidden="true"></i>aliquip ex ea commodo Duis aute irure dolo</li>
					</ul>
				</div>
				<div class="add-info">
					<h5>NOTE</h5>
					<ul class="csr-demo-list">
						<li><i class="fa fa-circle" aria-hidden="true"></i>Donations and gift giving</li>
						<li><i class="fa fa-circle" aria-hidden="true"></i>Donations and gift giving</li>
						<li><i class="fa fa-circle" aria-hidden="true"></i>aliquip ex ea commodo Duis aute irure dolo</li>
					</ul>
					<p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod quis nostrud exercitation ullamco udied in the National Technical University of Athehe National Technical University of Athens, Greece (NTUA), with a Master  I am an Archit laboris nisi ut aliquip ex ea commodo Duis aute irure dolor in reprehenderit in voluptate velit essecillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non sunt in culpa qui officia d</p>
				</div>
				
			</div>
		</div>
	</div>




<?php include 'includes/footer.php'; ?>





</body>
</html>