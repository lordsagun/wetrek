<!DOCTYPE html>
<html>

<?php include 'includes/header.php'; ?>


<body>


	<div class="about-us-inside">
		<div class="about-banner">
			<div class="about-banner-contain">
				<div class="about-banner-content destination">
					<div class="container">
						<h1>About we trek<strong>Land of Himalayas</strong></h1>
					</div>
				</div>
				<div class="about-head-wr">
					<div class="container">
						<div class="about-tab-head">
							<ul class="nav nav-pills">
							    <li class="active"><a data-toggle="pill" href="#home">About Nepal</a></li>					
							    <li><a data-toggle="pill" href="#menu1">Why Travel With Us</a></li>
							    <li><a data-toggle="pill" href="#menu2">Visa Information</a></li>
							    <li><a data-toggle="pill" href="#menu3">Travel Tips</a></li>
							    <li><a data-toggle="pill" href="#menu4">Recommended Readings</a></li>
							</ul>
						</div>	
					</div>
				</div>				
			</div>
		</div>

		<div class="about-content">
			<div class="container">
				<div class="row">
					<div class="tab-content col-lg-9 col-md-9 col-sm-12">
					    <div id="home" class="tab-pane fade in active about-tab-content">
					      <h3>Nepal</h3>
					      <p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod quis nostrud exercitation ullamco udied in the National Technical University of Athehe National Technical University of Athens, Greece (NTUA), with a Master  I am an Archit laboris nisi ut aliquip ex ea commodo Duis aute irure dolor in reprehenderit in voluptate velit essecillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non sunt in culpa qui officia deserunt mollit anim id est laborum. am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master  I am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master I am an Architect Engineer, studied in the National Technical University of Athehe National Technical University of Athens, Greece (NTUA), with a Masters, Greece (NTUA),  eiusmod quis nostrud exercitation ullamco udied in the National Technical University of Athehe National Technical University of Athens, Greece (NTUA), with a Master  I am an Archit laboris nisi ut aliquip ex ea commodo Duis aute irure dolor in University of Athehe National  velit essec with a Master I am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master .</p>
					      <ul class="demo-list">
					      	<li>University of Athehe National </li>
					      	<li>deserunt mollit anim</li>
					      	<li>Athens, Greece <a href="">(NTUA)</a>,</li>
					      </ul>
					    </div>
					    <div id="menu1" class="tab-pane fade why-travel">
					      <h3>Why Travel with us</h3>
					      <div class="why-travel-content-wr">
					      	<div class="why-travel-content clearfix">
					      		<div class="icon-contain"><span class="icon-wrapper"><img src="images/why-icon.png" alt="icon"></span></div>
					      		<div class="why-travel-text">
					      			<h4>25 Years of Experience</h4>
					      			<p>I am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master  I am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master I am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master I am an Architect Engineer, studied</p>
					      		</div>
					      	</div>
					      	<div class="why-travel-content clearfix">
					      		<div class="icon-contain"><span class="icon-wrapper"><img src="images/why-icon.png" alt="icon"></span></div>
					      		<div class="why-travel-text">
					      			<h4>25 Years of Experience</h4>
					      			<p>I am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master  I am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master I am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master I am an Architect Engineer, studied</p>
					      		</div>
					      	</div>
					      	<div class="why-travel-content clearfix">
					      		<div class="icon-contain"><span class="icon-wrapper"><img src="images/why-icon.png" alt="icon"></span></div>
					      		<div class="why-travel-text">
					      			<h4>25 Years of Experience</h4>
					      			<p>I am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master  I am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master I am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master I am an Architect Engineer, studied</p>
					      		</div>
					      	</div>
					      </div>
					    </div>
					    <div id="menu2" class="tab-pane fade why-travel about-tab-content">
					    	<h3>Visa Information</h3>
						     <p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod quis nostrud exercitation ullamco udied in the National Technical University of Athehe National Technical University of Athens, Greece (NTUA), with a Master  I am an Archit laboris nisi ut aliquip ex ea commodo Duis aute irure dolor in reprehenderit in voluptate velit essecillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat National  velit essec with a Master I am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master .</p>
							<ul class="demo-list">
								<li>University of Athehe National </li>
								<li>deserunt mollit anim</li>
								<li>Athens, Greece <a href="">(NTUA)</a>,</li>
							</ul>
						    
					    </div>
					    <div id="menu3" class="tab-pane fade why-travel about-tab-content">
					    	<h3>Travel Trips</h3>
						     <p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod quis nostrud exercitation ullamco udied in the National Technical University of Athehe National Technical University of Athens, Greece (NTUA), with a Master  I am an Archit laboris nisi ut aliquip ex ea commodo Duis aute irure dolor in reprehenderit in voluptate velit essecillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat National  velit essec with a Master I am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master .</p>
							<ul class="demo-list">
								<li>University of Athehe National </li>
								<li>deserunt mollit anim</li>
								<li>Athens, Greece <a href="">(NTUA)</a>,</li>
							</ul>
						    
					    </div>
					    <div id="menu4" class="tab-pane fade why-travel about-tab-content">
					    	<h3>Recommended Readings</h3>
						     <p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod quis nostrud exercitation ullamco udied in the National Technical University of Athehe National Technical University of Athens, Greece (NTUA), with a Master  I am an Archit laboris nisi ut aliquip ex ea commodo Duis aute irure dolor in reprehenderit in voluptate velit essecillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non sunt in culpa qui officia deserunt mollit anim id est laborum. am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master  I am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master I am an Architect Engineer, studied in the National Technical University of Athehe National Technical University of Athens, Greece (NTUA), with a Masters, Greece (NTUA),  eiusmod quis nostrud exercitation ullamco udied in the National Technical University of Athehe National Technical University of Athens, Greece (NTUA), with a Master  I am an Archit laboris nisi ut aliquip ex ea commodo Duis aute irure dolor in University of Athehe National  velit essec with a Master I am an Architect Engineer, studied in the National Technical University of Athens, Greece (NTUA), with a Master .</p>
							<ul class="demo-list">
								<li>University of Athehe National </li>
								<li>deserunt mollit anim</li>
								<li>Athens, Greece <a href="">(NTUA)</a>,</li>
							</ul>
						    
					    </div>
					</div>

					<div class="about-side-bar col-lg-3 col-md-3 col-sm-12">
						<div class="trip-finder">
							<span><img src="images/trip-finder.png" alt="trip"></span>
							<a href="#">Find trips in Nepal</a>
						</div>
				  		<div class="side-popular">
				  			<h3>Popular <strong>Trips</strong></h3>
				  			<div class="trips clearfix">
				  				<div class="trips-wr">
				  					<p><a href="#">Everest Base Camp</a></p>
				  					<span><strong>18</strong> Days</span>
				  				</div>
				  				<div class="icon-wr">
				  					<a href="#"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i></a>
				  				</div>
				  			</div>
				  			<div class="trips clearfix">
				  				<div class="trips-wr">
				  					<p><a href="#">Everest Base Camp</a></p>
				  					<span><strong>18</strong> Days</span>
				  				</div>
				  				<div class="icon-wr">
				  					<a href="#"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i></a>
				  				</div>
				  			</div>
				  			<div class="trips clearfix">
				  				<div class="trips-wr">
				  					<p><a href="#">Everest Base Camp</a></p>
				  					<span><strong>18</strong> Days</span>
				  				</div>
				  				<div class="icon-wr">
				  					<a href="#"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i></a>
				  				</div>
				  			</div>				  		
				  			<div class="trips clearfix">
				  				<div class="trips-wr">
				  					<p><a href="#">Everest Base Camp</a></p>
				  					<span><strong>18</strong> Days</span>
				  				</div>
				  				<div class="icon-wr">
				  					<a href="#"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i></a>
				  				</div>
				  			</div>
				  			<div class="trips clearfix">
				  				<div class="trips-wr">
				  					<p><a href="#">Everest Base Camp</a></p>
				  					<span><strong>18</strong> Days</span>
				  				</div>
				  				<div class="icon-wr">
				  					<a href="#"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i></a>
				  				</div>
				  			</div>
				  			<div class="trips clearfix">
				  				<div class="trips-wr">
				  					<p><a href="#">Everest Base Camp</a></p>
				  					<span><strong>18</strong> Days</span>
				  				</div>
				  				<div class="icon-wr">
				  					<a href="#"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i></a>
				  				</div>
				  			</div>
				  			<div class="see-all">
				  				<a href="#">See All</a>
				  			</div>
				  		</div>

				  		<div class="expert-wr">
				  			<span>Speak to an expert</span>
				  			<span>+977 9851343564</span>
				  		</div>
				  		<div class="book-btn">
					  		<button>Booking Info</button>
					  	</div>
				  	</div>
				</div>
			</div>
		</div>
	</div>










<?php include 'includes/footer.php'; ?>





</body>
</html>